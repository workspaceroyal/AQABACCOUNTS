<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>About Page</title>
</head>
<body>
<h1>This is About Page from controller </h1>
<a href="{{ route('cotact.page') }}"> Contact </a>
</body>
</html>