<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                 AQAB © aqab@gmail.com.com.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    স্বত্ব <i class="mdi mdi-heart text-danger"></i> AQAB কর্তৃক সর্বস্বত্ব সংরক্ষিত
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
<?php /**PATH E:\xampp\htdocs\Laravel Projects\AQABACCOUNTS\resources\views/editor/body/footer.blade.php ENDPATH**/ ?>