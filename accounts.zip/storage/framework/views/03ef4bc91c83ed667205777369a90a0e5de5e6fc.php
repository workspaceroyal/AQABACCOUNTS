<?php echo e($slot); ?>

<?php /**PATH E:\xampp\htdocs\Laravel Projects\inventory-management-system-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>