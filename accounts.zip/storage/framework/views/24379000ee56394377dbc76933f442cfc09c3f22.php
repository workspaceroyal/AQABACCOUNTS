<?php $__env->startSection('user'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

 <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0">ব্যয়ের খাত ভিত্তিক রিপোর্ট </h4>



                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">


    <div class="row">
        <div class="text-center col-md-12">
            <strong> ব্যয়ের খাত ভিত্তিক অগ্রিম রিপোর্ট </strong>
            <input type="radio" name="customer_wise_report" value="customer_wise_credit" class="search_value"> &nbsp;&nbsp;


            <strong> ব্যয়ের খাত ভিত্তিক পরিশোধনীয় রিপোর্ট </strong>
            <input type="radio" name="customer_wise_report" value="customer_wise_paid" class="search_value">


        </div>
    </div> <!-- // end row  -->

<!--  /// Customer Credit Wise  -->
    <div class="show_credit" style="display:none">
        <form method="GET" action="<?php echo e(route('user.customer.wise.credit.report')); ?>" id="myForm" target="_blank" >

            <div class="row">
                <div class="col-sm-8 form-group">
                    <label>ব্যয়ের খাত</label>
              <select name="customer_id" class="form-select select2"  >
                <option value="">ব্যয়ের খাত সিলেক্ট করুন</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cus->id); ?>"><?php echo e($cus->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>

                <div class="col-sm-4" style="padding-top: 28px;">
                    <button type="submit" class="btn btn-primary">সার্চ</button>
                </div>

            </div>

        </form>

    </div>
<!--  /// End Customer Credit Wise  -->

<!--  /// show_paid  -->
<div class="show_paid" style="display:none">
        <form method="GET" action="<?php echo e(route('user.customer.wise.paid.report')); ?>" id="myForm" target="_blank" >

            <div class="row">
                <div class="col-sm-8 form-group">
                    <label>ব্যয়ের খাত</label>
              <select name="customer_id" class="form-select select2"  >
                <option value="">ব্যয়ের খাত সিলেক্ট করুন</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cus->id); ?>"><?php echo e($cus->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>

                <div class="col-sm-4" style="padding-top: 28px;">
                    <button type="submit" class="btn btn-primary">সার্চ</button>
                </div>

            </div>

        </form>

    </div>
<!--  /// End show_paid  -->






                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->



                    </div> <!-- container-fluid -->
                </div>




<script type="text/javascript">
    $(document).on('change','.search_value', function(){
        var search_value = $(this).val();
        if (search_value == 'customer_wise_credit') {
            $('.show_credit').show();
        }else{
            $('.show_credit').hide();
        }
    });

</script>


<script type="text/javascript">
    $(document).on('change','.search_value', function(){
        var search_value = $(this).val();
        if (search_value == 'customer_wise_paid') {
            $('.show_paid').show();
        }else{
            $('.show_paid').hide();
        }
    });

</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel Projects\AQABACCOUNTS\resources\views/userbackend/customer/customer_wise_report.blade.php ENDPATH**/ ?>