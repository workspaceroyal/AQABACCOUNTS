<?php $__env->startSection('admin'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<div class="page-content">
<div class="container-fluid">

<div class="row">
<div class="col-12">
    <div class="card">
        <div class="card-body">

            <h4 class="card-title">তহবিল খাত যুক্ত করুন</h4><br><br>



 <form method="post" action="<?php echo e(route('product.store')); ?>" id="myForm" >
                <?php echo csrf_field(); ?>

            <div class="mb-3 row">
                <label for="example-text-input" class="col-sm-2 col-form-label">তহবিল খাত </label>
                <div class="form-group col-sm-10">
                    <input name="name" class="form-control" type="text"    >
                </div>
            </div>
            <!-- end row -->


            <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">আয়ের উৎস </label>
        <div class="col-sm-10">
            <select name="supplier_id" class="form-select" aria-label="Default select example">
                <option selected="">একটি সিলেক্ট করুন</option>
                <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($supp->id); ?>"><?php echo e($supp->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>
    </div>
  <!-- end row -->

      <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">মুদ্রা </label>
        <div class="col-sm-10">
            <select name="unit_id" class="form-select" aria-label="Default select example">
                <option selected="">একটি সিলেক্ট করুন</option>
                <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($uni->id); ?>"><?php echo e($uni->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>
    </div>
  <!-- end row -->



      <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">অর্থের খাত </label>
        <div class="col-sm-10">
            <select name="category_id" class="form-select" aria-label="Default select example">
                <option selected="">একটি সিলেক্ট করুন</option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>
    </div>
  <!-- end row -->


<input type="submit" class="btn btn-info waves-effect waves-light" value="যুক্ত করুন">
            </form>



        </div>
    </div>
</div> <!-- end col -->
</div>



</div>
</div>

<script type="text/javascript">
    $(document).ready(function (){
        $('#myForm').validate({
            rules: {
                name: {
                    required : true,
                },
                 supplier_id: {
                    required : true,
                },
                 unit_id: {
                    required : true,
                },
                 category_id: {
                    required : true,
                },
            },
            messages :{
                name: {
                    required : 'তহবিল খাত যুক্ত করুন',
                },
                supplier_id: {
                    required : 'আয়ের উৎস সিলেক্ট করুন',
                },
                unit_id: {
                    required : 'কারেন্সি সিলেক্ট করুন',
                },
                category_id: {
                    required : 'আয়ের খাত সিলেক্ট করুন',
                },
            },
            errorElement : 'span',
            errorPlacement: function (error,element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight : function(element, errorClass, validClass){
                $(element).addClass('is-invalid');
            },
            unhighlight : function(element, errorClass, validClass){
                $(element).removeClass('is-invalid');
            },
        });
    });

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel Projects\AQABACCOUNTS\resources\views/backend/product/product_add.blade.php ENDPATH**/ ?>